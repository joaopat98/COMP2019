#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "nodes.h"
#include "symtab.h"

void code_gen(Scope *global);