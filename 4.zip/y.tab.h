/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ID = 258,
    INTLIT = 259,
    REALLIT = 260,
    STRLIT = 261,
    SEMICOLON = 262,
    BLANKID = 263,
    PACKAGE = 264,
    RETURN = 265,
    AND = 266,
    OR = 267,
    ASSIGN = 268,
    COMMA = 269,
    EQ = 270,
    NE = 271,
    GE = 272,
    GT = 273,
    LE = 274,
    LT = 275,
    LPAR = 276,
    RPAR = 277,
    LBRACE = 278,
    RBRACE = 279,
    LSQ = 280,
    RSQ = 281,
    MINUS = 282,
    PLUS = 283,
    STAR = 284,
    DIV = 285,
    MOD = 286,
    NOT = 287,
    IF = 288,
    ELSE = 289,
    FOR = 290,
    VAR = 291,
    INT = 292,
    FLOAT32 = 293,
    BOOL = 294,
    STRING = 295,
    PRINT = 296,
    PARSEINT = 297,
    FUNC = 298,
    CMDARGS = 299,
    RESERVED = 300,
    IMPORTANT = 301,
    PARS = 302
  };
#endif
/* Tokens.  */
#define ID 258
#define INTLIT 259
#define REALLIT 260
#define STRLIT 261
#define SEMICOLON 262
#define BLANKID 263
#define PACKAGE 264
#define RETURN 265
#define AND 266
#define OR 267
#define ASSIGN 268
#define COMMA 269
#define EQ 270
#define NE 271
#define GE 272
#define GT 273
#define LE 274
#define LT 275
#define LPAR 276
#define RPAR 277
#define LBRACE 278
#define RBRACE 279
#define LSQ 280
#define RSQ 281
#define MINUS 282
#define PLUS 283
#define STAR 284
#define DIV 285
#define MOD 286
#define NOT 287
#define IF 288
#define ELSE 289
#define FOR 290
#define VAR 291
#define INT 292
#define FLOAT32 293
#define BOOL 294
#define STRING 295
#define PRINT 296
#define PARSEINT 297
#define FUNC 298
#define CMDARGS 299
#define RESERVED 300
#define IMPORTANT 301
#define PARS 302

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 24 "gocompiler.y" /* yacc.c:1909  */

    tokeninfo token;
    Node *nodeval;
    node_type typeval;

#line 154 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
